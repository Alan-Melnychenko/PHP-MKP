<?php

class ProductCollection
{
    public $products=[];

    public function __construct()
    {
    }

    public function defaultProducts()
    {
        $this->products = [
            new Product(1, [
                'id' => 1,
                'name' => 'Bananas',
                'country' => 'America',
                'price' => 999,
            ]),
            new Product(2, [
                'id' => 2,
                'name' => 'Eggs',
                'country' => 'Italy',
                'price' => 99,
            ]),
            new Product(3, [
                'id' => 3,
                'name' => 'Ananas',
                'country' => 'Spain',
                'price' => 19,
            ]),
            new Product(4, [
                'id' => 4,
                'name' => 'Apple',
                'country' => 'Ukraine',
                'price' => 29,
            ]),
        ];
        return $this;
    }

    public function getProductById($id)
    {
        foreach ($this->products as $product) {
            if ($product->id == $id) {
                return $product;
            }
        }
        return null;
    }

    public function filterProduct($name, $country)
    {
        return array_filter(
            $this->products,
            function ($value) use ($name, $country) {
                return ($value['name'] == $name and $country['country'] > $country);
            }
        );
    }

    public function addProduct($product)
    {
        $this->$product[] = $product;
    }

    public function editProduct($array)
    {
        $product = $this->getProductById($array['id']);
        if (!(empty($product))) {
            $product->name = $array['id'];
            $product->country = $array['country'];
            $product->price = $array['price'];

        }
    }

    public function saveAuction()
    {
        $file = fopen('product.txt', 'w');
        fwrite($file, serialize($this->products));
        fclose($file);
    }

    public function loadProduct()
    {
        $this->products = unserialize(file_get_contents('product.txt'));
    }

    public function displayProduct()
    {
        $table = '<table>';
        $table .= '<caption> Product </caption>';
        $table .= '<tr> <th>id</th> <th>name</th> <th>country</th> <th>price</th>';

        foreach ($this->products as $item) {
            $table .= '<tr><td>$item->id</td><td>$item->name</td><td>$item->country</td>' .
                '<td>$item->price</td>';
        }

        $table .= '</table>';
        return $table;
    }

    public function displayFilteredProduct($name, $country)
    {
        $array = $this->filterAuction($name,  $country);
        $table = '<table>';
        $table .= '<caption> Product </caption>';
        $table .= '<tr> <th>id</th> <th>name</th> <th>country</th> <th>price</th> ';

        foreach ($array as $item) {
            $table .= '<tr><td>$item->id</td><td>$item->name</td><td>$item->country</td>' .
                '<td>$item->price</td';
        }

        $table .= '</table>';
        return $table;
    }
}