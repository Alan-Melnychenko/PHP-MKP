<?php

class Product
{
    public $id;
    public $name;
    public $country;
    public $price;

    public function __construct($id, $array)
    {
        $this->id = $id;
        $this->name = $array['name'];
        $this->country= $array['country'];
        $this->price = $array['price'];

    }

    public static function validationDataProduct($array)
    {
        return !(
            empty($array['name']) ||
            empty($array['country']) ||
            empty($array['price']) ||
            !isset($array)
        );
    }
}