<?php

class Repository
{
    public function saveProduct($array)
    {
        $file = fopen("product.txt", "w");
        fwrite($file, serialize($array));
        fclose($file);
    }

    public function loadProduct()
    {
        $this->product = unserialize(file_get_contents("product.txt"));
    }
}