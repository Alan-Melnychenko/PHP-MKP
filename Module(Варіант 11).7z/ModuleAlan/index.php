<?php

//include "Auction.php";
//include "AuctionCollections.php";

$dbh = new PDO('mysql:host=localhost;dbname=Product', 'root', '');

function myAutoloader($class_name)
{
    if (!class_exists($class_name)) {
        include $class_name . '.php';
    }
}

spl_autoload_register('myAutoloader');


if (!isset($_SESSION)) {
    session_start();
}

if (empty($_SESSION['Product'])) {
    $_SESSION['Product'] = new ProductCollection();
    $_SESSION['Product']->defaultProducts();
}

$actionToDo = $_POST['action'];

if ($actionToDo == 'add') {
    if (Product::validationDataProduct($_POST)) {
        $_SESSION['Product']->addProduct(
            new Product(5, $_POST)
        );
    }
} elseif ($actionToDo == 'edit') {
    if (Product::validationDataProduct($_POST)) {
        $_SESSION['Auction']->editProduct(
            $_POST
        );
    }
} elseif ($actionToDo == 'filter') {
    echo $_SESSION['Auction']->filterProduct($_POST['name'], $_POST['country']);
} elseif ($actionToDo == 'save') {
    $_SESSION['Auction']->saveProduct();
} elseif ($actionToDo == 'load') {
    $_SESSION['Auction']->loadProduct();
}


echo (new Display)->displayProduct($_SESSION['Product']->products)
?>
<br>

<button onclick="ShowAddForm()"> ADD</button>
<button onclick="ShowEditForm()"> EDIT</button>
<button onclick="ShowFilterForm()"> FILTER</button>

<br>

<form action='<?= $_SERVER['PHP_SELF'] ?>' method='post' id='addForm'>
    ADD <br>
    <label> name:
        <input type='text' name='name'>
    </label><br>
    <label> country:
        <input type='text' name='country'>
    </label><br>
    <label> price:
        <input type='number' name='price'>
    </label><br>
    <input type='hidden' name='action' value='add'>
    <input type='submit' value='add'>
</form>

<br>

<form action='<?= $_SERVER['PHP_SELF'] ?>' method='post' id='editForm'>
    EDIT <br>
    <label> name:
        <input type='text' name='name'>
    </label><br>
    <label> country:
        <input type='text' name='country'>
    </label><br>
    <label> price:
        <input type='number' name='price'>
    </label><br>
    <input type='hidden' name='action' value='edit'>
    <input type='submit' value='edit'>
</form>

<br>

<form action='<?= $_SERVER['PHP_SELF'] ?>' method='post' id='filterForm'>
    Filter <br>
    <label> name:
        <input type='text' name='name'>
    </label><br>
    <label> country:
        <input type='text' name='country'>
    </label><br>
    <input type='hidden' name='action' value='filter'>
    <input type='submit' value='filter'>
</form>

<form action='<?= $_SERVER['PHP_SELF'] ?>' method='post' id='save'>
    <input type='hidden' name='action' value='save'>
    <input type='submit' value='Save to file'>
</form>

<form action='<?= $_SERVER['PHP_SELF'] ?>' method='post' id='load'>
    <input type='hidden' name='action' value='load'>
    <input type='submit' value='Upload from file'>
</form>

<style>
    #addForm {
        display: none;
    }

    #editForm {
        display: none;
    }

    #filterForm {
        display: none;
    }

    table, th, td {
        border: 1px solid;
        text-align: center;
        background-color: darkorange;
    }

    th {
        width: 100px;
    }

    td {
        height: 50px;
    }
</style>

<script>
    function ShowAddForm() {
        document.querySelector('#addForm').style.display = 'inline';
    }

    function ShowEditForm() {
        document.querySelector('#editForm').style.display = 'inline';
    }

    function ShowFilterForm() {
        document.querySelector('#filterForm').style.display = 'inline';
    }
</script>