<?php

class Display


{
    public function displayProduct($array)
    {
        $table = '<table>';
        $table .= "<caption> Product </caption>";
        $table .= '<tr> <th>id</th> <th>name</th> <th>country</th> <th>price</th> ';

        foreach ($array as $item) {
            $table .= "<tr><td>$item->id</td><td>$item->name</td><td>$item->country</td>" .
                "<td>$item->price</td>";
        }

        $table .= '</table>';
        return $table;
    }

}